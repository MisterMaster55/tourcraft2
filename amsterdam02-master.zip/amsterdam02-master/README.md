# .env Next.js requires NEXT_PUBLIC_ prefix for client-side variables
```bash

NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANONKE=
NEXT_PUBLIC_SUPABASE_PROJECT_ID=
```
